# FCM Booster Advanced - LSPosed Module
## Cara Build & Install

================================================
## STRUKTUR PROJECT
================================================

FCMBoosterAdvanced/
├── app/
│   ├── src/main/
│   │   ├── java/com/fcmbooster/
│   │   │   └── FCMBoosterHook.java     ← HOOK UTAMA
│   │   ├── assets/
│   │   │   └── xposed_init             ← Entry point LSPosed
│   │   ├── res/values/
│   │   │   └── strings.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties

================================================
## CARA BUILD (Butuh Android Studio)
================================================

LANGKAH 1: Persiapan
  - Install Android Studio (versi Hedgehog / Iguana)
  - Install JDK 11 atau lebih tinggi
  - Pastikan Android SDK terinstall

LANGKAH 2: Buka Project
  - Buka Android Studio
  - File → Open → pilih folder FCMBoosterAdvanced
  - Tunggu Gradle sync selesai

LANGKAH 3: Build APK
  - Build → Build Bundle(s) / APK(s) → Build APK(s)
  - Tunggu build selesai
  - APK ada di: app/build/outputs/apk/release/app-release.apk
  - Atau via terminal: ./gradlew assembleRelease

LANGKAH 4: Install APK ke HP
  - Transfer APK ke HP
  - Install APK (aktifkan "Install dari sumber tidak dikenal")
  - Buka LSPosed Manager
  - Cari "FCM Booster Advanced" di daftar module
  - Aktifkan module
  - Centang scope: "Google Play Services"
  - Reboot HP

================================================
## CARA VERIFIKASI
================================================

1. Buka *#*#426#*#* setelah reboot
2. Cek "Last Heartbeat" - harusnya interval ~60 detik
3. Cek Xposed Log di LSPosed Manager:
   - Cari tag "FCMBooster"
   - Harusnya muncul log setiap hook berhasil

4. Via ADB:
   adb shell logcat -s FCMBooster
   (lihat log hook real-time)

================================================
## HOOK YANG AKTIF
================================================

HOOK 1: McsManagedChannel.getHeartbeatIntervalMs()
  → Return: 60000ms (1 menit)
  → Default GMS: 1.680.000ms (28 menit)

HOOK 2: HeartbeatTask.getDelay()
  → Return: 60000ms
  → Mencegah scheduler delay heartbeat

HOOK 3: HeartbeatTask.scheduleHeartbeat(long)
  → Override argument → 60000ms
  → Paksa interval saat penjadwalan

HOOK 4: AdaptiveHeartbeatController.isAdaptiveHeartbeatEnabled()
  → Return: false
  → Matikan adaptive (auto-reduce saat baterai hemat)

HOOK 5: AdaptiveHeartbeatController.getHeartbeatIntervalForNetworkType()
  → WiFi   : 60 detik
  → Mobile : 60 detik
  → Roaming: 120 detik

HOOK 6: McsNetworkManager.getMinHeartbeatIntervalMs()
  → Return: 30000ms (minimum 30 detik)

HOOK 7: McsManagedChannel.getReconnectDelayMs()
  → Return: 1000ms (1 detik)
  → Default: bisa sampai 30+ detik

HOOK 8: McsInputStream.getSocketTimeoutMs()
  → Return: 300000ms (5 menit)
  → Cegah socket timeout terlalu cepat

HOOK 9: CheckinService.getCheckinInterval() [GSF]
  → Return: 3600000ms (1 jam)
  → Default: 86400000ms (24 jam)

================================================
## KOMBINASI OPTIMAL
================================================

Gunakan BERSAMAAN dengan Magisk Module:
  ┌─────────────────────────────────────┐
  │ Magisk Module FCMBooster v2.1       │
  │  → TCP kernel, DNS, OOM, Doze       │
  │  → Infrastruktur jaringan           │
  │                                     │
  │ LSPosed Module FCMBooster           │
  │  → Hook heartbeat interval GMS      │
  │  → Bypass adaptive heartbeat        │
  │  → Reconnect cepat                  │
  └─────────────────────────────────────┘

Urutan Install:
  1. Install Magisk Module v2.1 → Reboot
  2. Install LSPosed (jika belum ada)
  3. Install APK LSPosed Module ini
  4. Aktifkan di LSPosed → scope GMS
  5. Reboot
  6. Verifikasi *#*#426#*#*

================================================
## CATATAN PENTING
================================================

- GMS sering update dan obfuscate nama class
- Jika hook gagal, cek log LSPosed untuk error
- Module tetap aman meski beberapa hook gagal
  (ada fallback untuk class yang ter-obfuscate)
- Tidak perlu uninstall saat GMS update,
  tapi restart LSPosed scope jika heartbeat
  kembali ke 28 menit setelah GMS update

================================================
## TROUBLESHOOT
================================================

Problem : Last ping di *#*#426#*#* tidak berubah
Solution: 
  1. Pastikan scope GMS dicentang di LSPosed
  2. Force stop GMS: Settings → Apps → GMS → Force Stop
  3. Reboot ulang
  4. Cek log LSPosed ada error atau tidak

Problem : LSPosed tidak detect module
Solution:
  1. Pastikan APK terinstall
  2. Pastikan xposed_init ada di assets
  3. Rebuild APK dan reinstall

Problem : Hook error di log
Solution:
  GMS mungkin sudah update dan nama class berubah
  Perlu update hook dengan nama class terbaru
  via decompile GMS menggunakan jadx-gui
