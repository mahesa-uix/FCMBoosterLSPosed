package com.fcmbooster;

import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * FCM Booster LSPosed Module
 * Hook langsung ke Google Play Services untuk:
 * 1. Override FCM/MCS heartbeat interval
 * 2. Bypass adaptive heartbeat reduction
 * 3. Force persistent FCM connection
 * 4. Override network type throttle
 */
public class FCMBoosterHook implements IXposedHookLoadPackage {

    private static final String TAG = "FCMBooster";

    // Target packages
    private static final String GMS_PACKAGE = "com.google.android.gms";
    private static final String GSF_PACKAGE = "com.google.android.gsf";

    // Heartbeat interval dalam milidetik
    private static final long HEARTBEAT_INTERVAL_MS   = 60000L;  // 1 menit
    private static final long HEARTBEAT_MIN_MS         = 30000L;  // 30 detik minimum
    private static final long HEARTBEAT_WIFI_MS        = 60000L;  // 1 menit via WiFi
    private static final long HEARTBEAT_MOBILE_MS      = 60000L;  // 1 menit via data
    private static final long HEARTBEAT_ROAMING_MS     = 120000L; // 2 menit roaming
    private static final long RECONNECT_DELAY_MS       = 1000L;   // 1 detik reconnect

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // ============================================
        // HOOK GOOGLE PLAY SERVICES
        // ============================================
        if (lpparam.packageName.equals(GMS_PACKAGE)) {
            XposedBridge.log(TAG + ": Hooking Google Play Services...");

            hookMcsManager(lpparam.classLoader);
            hookHeartbeatTask(lpparam.classLoader);
            hookAdaptiveHeartbeat(lpparam.classLoader);
            hookNetworkThrottle(lpparam.classLoader);
            hookReconnectDelay(lpparam.classLoader);
            hookSocketTimeout(lpparam.classLoader);

            XposedBridge.log(TAG + ": All GMS hooks applied!");
        }

        // ============================================
        // HOOK GOOGLE SERVICES FRAMEWORK
        // ============================================
        if (lpparam.packageName.equals(GSF_PACKAGE)) {
            XposedBridge.log(TAG + ": Hooking Google Services Framework...");
            hookGsfCheckin(lpparam.classLoader);
        }
    }

    // ================================================
    // HOOK 1: MCS Manager - Heartbeat Interval Utama
    // Ini method paling penting untuk FCM heartbeat
    // ================================================
    private void hookMcsManager(ClassLoader cl) {
        try {
            // Method getHeartbeatInterval - return interval dalam ms
            hookMethodReturn(cl,
                "com.google.android.gms.gcm.mcs.McsManagedChannel",
                "getHeartbeatIntervalMs",
                HEARTBEAT_INTERVAL_MS,
                "McsManager.getHeartbeatIntervalMs"
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookMcsManager error: " + t.getMessage());
        }

        try {
            hookMethodReturn(cl,
                "com.google.android.gms.gcm.mcs.McsManager",
                "getHeartbeatInterval",
                (int)(HEARTBEAT_INTERVAL_MS),
                "McsManager.getHeartbeatInterval"
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookMcsManager (v2) error: " + t.getMessage());
        }

        try {
            // Obfuscated class name (GMS sering obfuscate)
            Class<?> mcsClass = findClassSafe(cl,
                "com.google.android.gms.gcm.a",   // obfuscated v1
                "com.google.android.gms.gcm.b",   // obfuscated v2
                "com.google.android.gms.iid.a"    // obfuscated v3
            );
            if (mcsClass != null) {
                hookAllMethodsReturningLong(mcsClass, HEARTBEAT_INTERVAL_MS);
                XposedBridge.log(TAG + ": Obfuscated MCS class hooked: " + mcsClass.getName());
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookMcsManager obfuscated error: " + t.getMessage());
        }
    }

    // ================================================
    // HOOK 2: HeartbeatTask - Task scheduler FCM
    // ================================================
    private void hookHeartbeatTask(ClassLoader cl) {
        try {
            // Hook getDelay() pada HeartbeatTask
            XposedHelpers.findAndHookMethod(
                "com.google.android.gms.gcm.mcs.HeartbeatTask",
                cl,
                "getDelay",
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) {
                        XposedBridge.log(TAG + ": HeartbeatTask.getDelay() -> " + HEARTBEAT_INTERVAL_MS);
                        return HEARTBEAT_INTERVAL_MS;
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookHeartbeatTask error: " + t.getMessage());
        }

        try {
            // Hook scheduleHeartbeat
            XposedHelpers.findAndHookMethod(
                "com.google.android.gms.gcm.mcs.HeartbeatTask",
                cl,
                "scheduleHeartbeat",
                long.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        // Override argument interval ke nilai kita
                        param.args[0] = HEARTBEAT_INTERVAL_MS;
                        XposedBridge.log(TAG + ": HeartbeatTask.scheduleHeartbeat() interval forced to " + HEARTBEAT_INTERVAL_MS);
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookHeartbeatTask (schedule) error: " + t.getMessage());
        }
    }

    // ================================================
    // HOOK 3: Adaptive Heartbeat - Android auto-reduce heartbeat
    // Ini yang bikin interval jadi makin lama saat baterai hemat
    // ================================================
    private void hookAdaptiveHeartbeat(ClassLoader cl) {
        try {
            // Matikan adaptive heartbeat reduction
            XposedHelpers.findAndHookMethod(
                "com.google.android.gms.gcm.mcs.AdaptiveHeartbeatController",
                cl,
                "isAdaptiveHeartbeatEnabled",
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) {
                        XposedBridge.log(TAG + ": AdaptiveHeartbeat disabled");
                        return false; // Matikan adaptive (tidak kurangi interval)
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookAdaptiveHeartbeat error: " + t.getMessage());
        }

        try {
            // Override getAdaptiveHeartbeatIntervalMs
            hookMethodReturn(cl,
                "com.google.android.gms.gcm.mcs.AdaptiveHeartbeatController",
                "getAdaptiveHeartbeatIntervalMs",
                HEARTBEAT_INTERVAL_MS,
                "AdaptiveHeartbeat.getInterval"
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookAdaptiveHeartbeat interval error: " + t.getMessage());
        }

        try {
            // Hook method yang bisa tambah delay saat Doze
            XposedHelpers.findAndHookMethod(
                "com.google.android.gms.gcm.mcs.AdaptiveHeartbeatController",
                cl,
                "getHeartbeatIntervalForNetworkType",
                int.class, // networkType
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) {
                        int netType = (int) param.args[0];
                        long interval;
                        // networkType: 0=MOBILE, 1=WIFI, 5=ROAMING
                        switch (netType) {
                            case 0:  interval = HEARTBEAT_MOBILE_MS; break;
                            case 1:  interval = HEARTBEAT_WIFI_MS;   break;
                            case 5:  interval = HEARTBEAT_ROAMING_MS; break;
                            default: interval = HEARTBEAT_INTERVAL_MS;
                        }
                        XposedBridge.log(TAG + ": HeartbeatForNetType(" + netType + ") -> " + interval);
                        return interval;
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookAdaptiveHeartbeat netType error: " + t.getMessage());
        }
    }

    // ================================================
    // HOOK 4: Network Throttle Override
    // GMS mengurangi frekuensi FCM saat sinyal lemah
    // ================================================
    private void hookNetworkThrottle(ClassLoader cl) {
        try {
            hookMethodReturn(cl,
                "com.google.android.gms.gcm.mcs.McsNetworkManager",
                "getMinHeartbeatIntervalMs",
                HEARTBEAT_MIN_MS,
                "McsNetworkManager.getMinHeartbeat"
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookNetworkThrottle error: " + t.getMessage());
        }

        try {
            // Override getMaxHeartbeatIntervalMs supaya tidak naik terlalu tinggi
            hookMethodReturn(cl,
                "com.google.android.gms.gcm.mcs.McsNetworkManager",
                "getMaxHeartbeatIntervalMs",
                HEARTBEAT_INTERVAL_MS * 2, // maks 2 menit
                "McsNetworkManager.getMaxHeartbeat"
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookNetworkThrottle max error: " + t.getMessage());
        }
    }

    // ================================================
    // HOOK 5: Reconnect Delay
    // Percepat reconnect saat koneksi FCM putus
    // ================================================
    private void hookReconnectDelay(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.gms.gcm.mcs.McsManagedChannel",
                cl,
                "getReconnectDelayMs",
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) {
                        XposedBridge.log(TAG + ": Reconnect delay -> " + RECONNECT_DELAY_MS + "ms");
                        return RECONNECT_DELAY_MS;
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookReconnectDelay error: " + t.getMessage());
        }
    }

    // ================================================
    // HOOK 6: Socket Timeout
    // Perpanjang timeout agar koneksi tidak mudah putus
    // ================================================
    private void hookSocketTimeout(ClassLoader cl) {
        try {
            hookMethodReturn(cl,
                "com.google.android.gms.gcm.mcs.McsInputStream",
                "getSocketTimeoutMs",
                300000L, // 5 menit socket timeout
                "McsInputStream.getSocketTimeout"
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookSocketTimeout error: " + t.getMessage());
        }
    }

    // ================================================
    // HOOK 7: GSF Checkin interval
    // ================================================
    private void hookGsfCheckin(ClassLoader cl) {
        try {
            hookMethodReturn(cl,
                "com.google.android.gsf.checkin.CheckinService",
                "getCheckinInterval",
                3600000L, // 1 jam checkin (default 24 jam)
                "CheckinService.getCheckinInterval"
            );
            XposedBridge.log(TAG + ": GSF Checkin interval -> 1 hour");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hookGsfCheckin error: " + t.getMessage());
        }
    }

    // ================================================
    // HELPER: Hook method yang return long
    // ================================================
    private void hookMethodReturn(ClassLoader cl, String className, String methodName,
                                   final long returnValue, final String logLabel) {
        XposedHelpers.findAndHookMethod(
            className, cl, methodName,
            new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) {
                    XposedBridge.log(TAG + ": " + logLabel + "() -> " + returnValue);
                    return returnValue;
                }
            }
        );
        XposedBridge.log(TAG + ": Hooked " + logLabel);
    }

    // ================================================
    // HELPER: Hook method yang return int
    // ================================================
    private void hookMethodReturn(ClassLoader cl, String className, String methodName,
                                   final int returnValue, final String logLabel) {
        XposedHelpers.findAndHookMethod(
            className, cl, methodName,
            new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) {
                    XposedBridge.log(TAG + ": " + logLabel + "() -> " + returnValue);
                    return returnValue;
                }
            }
        );
        XposedBridge.log(TAG + ": Hooked " + logLabel);
    }

    // ================================================
    // HELPER: Cari class dari beberapa kemungkinan nama
    // (karena GMS sering di-obfuscate)
    // ================================================
    private Class<?> findClassSafe(ClassLoader cl, String... classNames) {
        for (String name : classNames) {
            try {
                return XposedHelpers.findClass(name, cl);
            } catch (XposedHelpers.ClassNotFoundError e) {
                // Coba nama berikutnya
            }
        }
        return null;
    }

    // ================================================
    // HELPER: Hook semua method yang return long
    // pada class yang sudah ditemukan
    // ================================================
    private void hookAllMethodsReturningLong(Class<?> clazz, final long returnValue) {
        for (java.lang.reflect.Method method : clazz.getDeclaredMethods()) {
            if (method.getReturnType() == long.class ||
                method.getReturnType() == Long.class) {
                try {
                    XposedBridge.hookMethod(method, new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(MethodHookParam param) {
                            return returnValue;
                        }
                    });
                    XposedBridge.log(TAG + ": Hooked long method: " + method.getName());
                } catch (Throwable t) {
                    // Skip jika gagal
                }
            }
        }
    }
}
